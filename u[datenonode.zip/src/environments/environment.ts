const projectName = 'GreeceTest';

export const environment = {
  production: false,
  projectNameKey: 'Greece test',
  projectYear: '2020',
  apiUrl: '//  https://my-json-server.typicode.com/stefani0/',
  landingPage: `/${projectName}/module1/`,

};
