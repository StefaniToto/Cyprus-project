export interface UserSimple {
    username:string, 
    pass:string 
}