import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';


@Injectable()
export class ProjectService {
 url: string;

  constructor(private _httpClient: HttpClient) {
  this.url = 'https://raw.githubusercontent.com/spinning-spindle/lab-fe/master/trip.geojson';
  }


  getProjects( ): Observable<any> {
    return this._httpClient.get<any>(
      `${this.url}`,
      {

      }
    );
  }
}
