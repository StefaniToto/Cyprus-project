import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule } from '@angular/material/dialog';
import { DashboardComponent } from './dashboard.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { MatSelectModule } from '@angular/material/select';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormlyModule } from '@ngx-formly/core';
import { GuideComponent } from './pages/guide/guide.component';
import { ConnectSharedModule } from 'src/shared/modules/ConnectSharedModule.module';
import { FormlySelectComponent } from './components/formly-select/formly-select.component';
import { MarkerService } from './service/markers/marker.service';
import { HttpClientModule } from '@angular/common/http';
import { PopupService } from './service/popup/popup.service';
import { StoreModule } from '@ngrx/store';
import { ProjectReducer } from './store/reducers/project.reducer';
import { EffectsModule } from '@ngrx/effects';
import { ProjectEffect } from './store/effects/project.effects';
import { ProjectService } from './service/project.service';


@NgModule({
  declarations: [
    DashboardComponent,
    GuideComponent

  ],
  imports: [
    HttpClientModule,

    CommonModule,
    DashboardRoutingModule,
    MatCardModule,
    MatDialogModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    ConnectSharedModule,
    StoreModule.forFeature('projectState', ProjectReducer),
    EffectsModule.forFeature([ProjectEffect]),



    FormlyModule.forChild({
      types: [
        {
          name: 'custom-select',
          component: FormlySelectComponent,
          extends: 'select',
        },
      ],
      validationMessages: [
        { name: 'required', message: 'This field is required!' },
      ],
    }),


  ],
  exports: [MatCardModule],
  entryComponents: [

  ],
  providers: [
    NgbActiveModal,
    MarkerService,
    PopupService,
    ProjectService,

  ],
})
export class DashboardModule { }
