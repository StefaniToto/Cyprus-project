import { Project } from './project.model';


export class AppState {
 
    projectState: { features: any };
    selectedProject: Project;


}
