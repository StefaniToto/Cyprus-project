export class SelectOption {
  title: string;
  value: string;
}
