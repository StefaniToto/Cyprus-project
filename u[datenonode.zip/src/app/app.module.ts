import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DefaultLayoutComponent } from './core/components/default-layout/default-layout.component';

import { FormlyModule } from '@ngx-formly/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './core/components/login/login.component';
import { formlyConfig } from './core/utility/configs';
import { FormlyBootstrapModule } from '@ngx-formly/bootstrap';
import { Error404Component } from './core/components/error404/error404.component';
import { environment } from 'src/environments/environment.prod';
import { FormlySelectComponent } from './dashboard/components/formly-select/formly-select.component';
import { ButtoniFormComponent, DatatableFormComponent } from './core';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ToasterModule } from 'angular2-toaster';
import { ServiceWorkerModule } from '@angular/service-worker';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

const APP_CONTAINERS = [
  DefaultLayoutComponent
];


@NgModule({
  declarations: [
    AppComponent,
    APP_CONTAINERS,
    LoginComponent,
    Error404Component,
    FormlySelectComponent,
    DatatableFormComponent,
    ButtoniFormComponent,
 

  ],
  imports: [
    FormlyModule.forRoot(formlyConfig),
    BrowserModule,
    AppRoutingModule, 
    FormsModule,
    FormlyBootstrapModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxDatatableModule,
    BrowserAnimationsModule, // required animations module
    ToasterModule.forRoot(), 
    ServiceWorkerModule.register('ngsw-worker.js', {enabled: environment.production}),
    StoreModule.forRoot({}),
    EffectsModule.forRoot(),
    StoreDevtoolsModule.instrument({ maxAge: 25, logOnly: environment.production }),
  


   FormlyModule.forChild({
    types: [
      {
        name: 'custom-select',
        component: FormlySelectComponent,
        extends: 'select',
      },
    ],
    validationMessages: [
      { name: 'required', message: 'This field is required!' },
    ],
  }), ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
  ],
  exports : [
    FormsModule,
    FormlyBootstrapModule,
    ReactiveFormsModule,
    BrowserAnimationsModule, // required animations module
    ToasterModule

  ],
  providers: [



  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
